/**
 *
 */
package com.ocean.test;


/**
 * @author ocean
 *
 */
public class OceanTest {

	public static void main(String[] args) {
//		HiddenHttpMethodFilter filter;
//		WebUtils utils;
//		WebRequest request;
//		RuntimeException exception;
//		System.out.println("".hashCode());
//		Throwable throwable;
//		Integer integer;
//		UploadListener listener;
//		System.out.println(MD5.MD5Encode(Long.valueOf(System.nanoTime()+"", 16)+""));
	}

}
