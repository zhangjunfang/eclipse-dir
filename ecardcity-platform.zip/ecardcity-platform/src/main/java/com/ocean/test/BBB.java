/**
 *
 */
package com.ocean.test;

/**
 * @Description :
 * @author : ocean
 * @date : 2014-4-25 上午09:53:01
 * @email : zhangjunfang0505@163.com
 * @Copyright : newcapec zhengzhou
 */
public class BBB {

	static{

		System.err.println("---------------------------------");

	}


	public static void main(String[] args) {
		System.out.println(-4%5);
		System.out.println(-4%-5);
		System.out.println(4%-5);
		System.out.println(-5%4);
		System.out.println(5%-4);
		System.out.println(-5%-4);
        double dd=2.53;
        System.out.println(++dd);

	}

}
