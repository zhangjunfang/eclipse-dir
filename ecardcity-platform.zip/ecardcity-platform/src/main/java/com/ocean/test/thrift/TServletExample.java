package com.ocean.test.thrift;

//public class TServletExample extends TServlet {
////        public TServletExample() {
////                super(
////                        new ServiceExample.Processor(
////                                new ServiceExampleImpl()),
////                                new TCompactProtocol.Factory()
////                );
////        }
//}
/**
 * <servlet> <description></description>
 * <display-name>TServletExample</display-name>
 * <servlet-name>TServletExample</servlet-name>
 * <servlet-class>example.TServletExample</servlet-class> </servlet>
 * <servlet-mapping> <servlet-name>TServletExample</servlet-name>
 * <url-pattern>/TServletExample</url-pattern> </servlet-mapping>
 */
