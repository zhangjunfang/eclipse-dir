/**
 *
 */
package com.ocean.test.thrift;

/**
 * @author ocean
 * date : 2014-4-19 下午08:36:39
 * email : zhangjunfang0505@163.com
 * Copyright : newcapec zhengzhou
 */
//public class Test01 {
//	@Test
//	public void testServlet() throws TTransportException, TException {
//	        // TODO : change this URL if it's not the right one ;o)
//	        // TODO : change this URL if it's not the right one ;o)
//	        // TODO : change this URL if it's not the right one ;o)
//	        String servletUrl = "http://localhost:8080/ThriftExample/TServletExample";
//
//	        THttpClient thc = new THttpClient(servletUrl);
//	        TProtocol loPFactory = new TCompactProtocol(thc);
//	        ServiceExample.Client client = new ServiceExample.Client(loPFactory);
//
//	        BeanExample bean = client.getBean(1, "string");
//	        Assert.assertEquals("OK", bean.getStringObject());
//	}
//}

