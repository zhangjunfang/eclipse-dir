package cn.newcapec.function.platform.ocean;

public abstract interface Cacheable
{
  public abstract int getCachedSize();
}