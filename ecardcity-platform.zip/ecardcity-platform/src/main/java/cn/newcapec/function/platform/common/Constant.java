/**
 *
 */
package cn.newcapec.function.platform.common;

/**
 * @author ocean date : 2014-4-22 上午10:19:06 email : zhangjunfang0505@163.com
 *         Copyright : newcapec zhengzhou
 */
public interface Constant {
	// 菜单根节点标识
	public static final String TREE_ROOT_SIGN = "0";
	// 应用注册--标准包
	public static final String APPTYPE_APP = "0";
	// 应用注册--自定义包
	public static final String APPTYPE_CUS = "1";

	//自定义包 删除标识
	public static final String APPTYPE_DELETE_SIGN = "1";
	//自定义包 正常标识
	public static final String APPTYPE_NORMAL_SIGN = "0";
}
