/**
 *
 */
package cn.newcapec.function.platform.common;

/**
 * @author ocean
 * date : 2014-4-17 上午10:28:25
 * email : zhangjunfang0505@163.com
 * Copyright : newcapec zhengzhou
 */
public enum CommonEnum {
	ANY,IP,LOGINLIMIT
}
