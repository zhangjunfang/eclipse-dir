/**
 *
 */
package cn.newcapec.function.platform.biz;

import java.util.List;

import cn.newcapec.function.platform.model.BusinessAppredit;
import cn.newcapec.function.platform.model.LegalPerson;
import cn.newcapec.function.platform.model.Menu;
import cn.newcapec.function.platform.model.Module;
import cn.newcapec.function.platform.model.User;
import cn.newcapec.function.platform.tree.model.Tree;

/**
 * @author ocean
 * date : 2014-4-17 上午11:51:40
 * email : zhangjunfang0505@163.com
 * Copyright : newcapec zhengzhou
 */
public interface Win8UIService  {

   List<Module>	findAllModule(User user, LegalPerson legalPerson);
   List<Menu> findAllMenu();
   List<Object> showTree(User user, LegalPerson legalPerson);
   List<Tree> showCusTree();
   List<BusinessAppredit> findStandardBusinessAppredit();
}
