/**
 *
 */
package cn.newcapec.function.platform.biz.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import cn.newcapec.framework.core.dao.db.SqlDataset;
import cn.newcapec.function.platform.biz.Win8UIService;
import cn.newcapec.function.platform.common.Constant;
import cn.newcapec.function.platform.model.BusinessAppredit;
import cn.newcapec.function.platform.model.LegalPerson;
import cn.newcapec.function.platform.model.Menu;
import cn.newcapec.function.platform.model.Module;
import cn.newcapec.function.platform.model.Role;
import cn.newcapec.function.platform.model.RoleGroup;
import cn.newcapec.function.platform.model.User;
import cn.newcapec.function.platform.tree.model.AssistTree;
import cn.newcapec.function.platform.tree.model.Tree;

/**
 * @author ocean
 * @date : 2014-4-22 上午11:14:57
 * @email : zhangjunfang0505@163.com
 * @Copyright : newcapec zhengzhou
 */
@Service()
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Transactional()
public class Win8UIServiceImpl implements Win8UIService, Serializable {

	private static final long serialVersionUID = 681398034096834898L;

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<Module> findAllModule(User user, LegalPerson legalPerson) {
		//1.应用模块
		//2.菜单
		//3.查询 客户法人授权信息
		//4.角色
		//5.角色组
		SqlDataset dataset = new SqlDataset();
		dataset.setSql("  select * from base_app_module  ");
		dataset.setClazz(Module.class);
		dataset.loadData();
		return dataset.getData();
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<Menu> findAllMenu() {
		SqlDataset dataset = new SqlDataset();
		dataset.setSql("  select * from base_menu   ");
		dataset.setClazz(Menu.class);
		dataset.loadData();
		return dataset.getData();
	}
	//查询角色组
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<RoleGroup> findRoleByUser(User user, LegalPerson legalPerson) {
		SqlDataset dataset = new SqlDataset();
		dataset.setSql("  select * from base_app_module  ");
		dataset.setClazz(RoleGroup.class);
		dataset.loadData();
		return dataset.getData();
	}
	//查询角色
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<Role> findUserOfRole(User user, LegalPerson legalPerson) {

		SqlDataset dataset = new SqlDataset();
		dataset.setSql("  select * from base_app_module  ");
		dataset.setClazz(Role.class);
		dataset.loadData();
		return dataset.getData();
	}
	//查询 客户法人授权信息
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<Module> findLegalPerson(User user, LegalPerson legalPerson) {
		//1.应用模块
		//2.菜单
		//3.查询 客户法人授权信息
		//4.角色
		//5.角色组
		SqlDataset dataset = new SqlDataset();
		dataset.setSql("  select * from base_app_module  ");
		dataset.setClazz(Module.class);
		dataset.loadData();
		return dataset.getData();
	}
	@Override
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<Object> showTree(User user, LegalPerson legalPerson) {
		List<Object> objects = new ArrayList<Object>(800);// 管理这个树节点
		List<Menu> menus = this.findAllMenu();
		List<Module> modules = this.findAllModule( user,  legalPerson);
		AssistTree assistTree = null;// 根节点
		for (Module module : modules) {
			assistTree = new AssistTree();
			// assistTree.setParent(null);//设置一级菜单的父节点是 null
			assistTree.setpModuleId("0");
			copyModuleToAssistTree(module, assistTree);
			AssistTree temp = null;
			for (Menu menu : menus) {
				if (menu.getSubsystemid().equals(module.getModuleid())) {
					temp = new AssistTree();
					copyMenuToAssistTree(menu, temp);// 添加二级菜单
					List<Object> list = new ArrayList<Object>(20);
					list.add(temp);
					if (Constant.TREE_ROOT_SIGN.equals(menu.getParentmenuid())) {
						// temp.setParent(assistTree);//设置二级菜单的父节点是 上级菜单
						temp.setpModuleId(assistTree.getpModuleId());// 设置二级菜单的父节点是
						assistTree.getChildren().add(temp);// 添加二级菜单 // 上级菜单
					} else {
						Tree tree = new Tree();
						copyMenuToTree(tree, menu);
						temp.getChildren().add(tree);// 添加三级节点
						assistTree.getChildren().add(temp);// 添加二级菜单[添加三级菜单的父菜单]
					}
				}
			}
			objects.add(assistTree);// 一级菜单
		}
		return objects;
	}

	private void copyModuleToAssistTree(Module module, AssistTree assistTree) {
		if (module == null) {
			return;
		}
		assistTree.setModuleId(module.getModuleid());
		assistTree.setModuleName(module.getModulename());
	}

	private void copyMenuToAssistTree(Menu menu, AssistTree assistTree) {
		if (menu == null) {
			return;
		}
		assistTree.setModuleId(menu.getMenuid());
		assistTree.setModuleName(menu.getMenuname());
	}

	private void copyMenuToTree(Tree tree, Menu menu) {
		if (menu == null) {
			return;
		}
		tree.setFile(menu.getNavlink());
		tree.setId(menu.getMenuid());
		tree.setName(menu.getMenuname());
		tree.setpId(menu.getParentmenuid());
	}

	@Override
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<Tree> showCusTree() {

		List<Tree> trees = new ArrayList<Tree>(200);
		List<BusinessAppredit> appredits = findStandardBusinessAppredit();
		changBusinessAppreditToTree(appredits, trees);
		List<Module> modules = findModuleByStandard(appredits);
		changModuleToTree(modules, trees);
		List<Menu> menus = findMenuByStandard(modules);
		changMenuToTree(menus, trees);
		return trees;
	}

	/**
	 * @param menus
	 * @param trees
	 */
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	private void changMenuToTree(List<Menu> menus, List<Tree> trees) {
		if (null == menus || menus.size() == 0) {
			return;
		} else {
			Tree subTree = null;
			for (Menu menu : menus) {
				subTree = new Tree(menu.getMenuid(), menu.getSubsystemid(),
						menu.getMenuname(), "", null);
				trees.add(subTree);
			}
		}

	}

	/**
	 * @param modules
	 * @param trees
	 */
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	private void changModuleToTree(List<Module> modules, List<Tree> trees) {
		if (null == modules || modules.size() == 0) {
			return;
		} else {

			Tree subTree = null;
			for (Module module : modules) {
				subTree = new Tree(module.getModuleid(), module.getAppid(),
						module.getModulename(), "", null);
				trees.add(subTree);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public List<BusinessAppredit> findStandardBusinessAppredit() {
		StringBuffer buffer = new StringBuffer(60);
		buffer.append("  select * from base_app_redit  where apptype=");
		buffer.append("'");
		buffer.append(Constant.APPTYPE_APP);
		buffer.append("'");
		SqlDataset dataset = new SqlDataset();
		dataset.setSql(buffer.toString());
		dataset.setClazz(BusinessAppredit.class);
		dataset.loadData();
		return dataset.getData();
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	private List<Module> findModuleByStandard(List<BusinessAppredit> appredits) {

		if (null == appredits || appredits.size() == 0) {
			return null;
		} else {
			StringBuffer buffer = new StringBuffer(200);
			buffer.append("  select rel.appid,rel.moduleid,mm.id,mm.modulecode,mm.reditedcode,mm.modulename,mm.limitnum,mm.limitdt,mm.reditdt,mm.reditasn,mm.description,mm.apptype,mm.opdt,mm.syscode,mm.sortid from  base_appmodule  rel  right join  base_app_module  mm  on  rel.moduleid=mm.moduleid  ");
			int i = 0;
			buffer.append(" where rel.appid in ( ");
			for (BusinessAppredit businessAppredit : appredits) {
				buffer.append("'");
				buffer.append(businessAppredit.getAppid());
				buffer.append("'");
				if (i != appredits.size() - 1) {
					buffer.append(" , ");
				}
				i++;
			}
			buffer.append(" ) ");
			SqlDataset dataset = new SqlDataset();
			dataset.setSql(buffer.toString());
			dataset.setClazz(Module.class);
			dataset.loadData();
			return dataset.getData();
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	private List<Menu> findMenuByStandard(List<Module> modules) {
		if (null == modules || modules.size() == 0) {
			return null;
		} else {
			StringBuffer buffer = new StringBuffer(200);
			buffer.append("   SELECT * FROM base_menu mm  ");
			int i = 0;
			buffer.append(" where mm.subsystemid in ( ");
			for (Module module : modules) {
				buffer.append(" ' ");
				buffer.append(module.getModuleid());
				buffer.append(" ' ");
				if (i != modules.size() - 1) {
					buffer.append(" , ");
				}
				i++;
			}
			buffer.append(" ) ");
			SqlDataset dataset = new SqlDataset();
			dataset.setSql(buffer.toString());
			dataset.setClazz(Menu.class);
			dataset.loadData();
			return dataset.getData();
		}

	}

	/**
	 * @param findStandardBusinessAppredit
	 * @param trees
	 */
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	private void changBusinessAppreditToTree(
			List<BusinessAppredit> findStandardBusinessAppredit,
			List<Tree> trees) {
		if (null == findStandardBusinessAppredit
				|| findStandardBusinessAppredit.size() == 0) {
			return;
		} else {
			// Tree tree = new Tree("QQQQQQQQ", Constant.TREE_ROOT_SIGN, "应用包信息列表", "", null);
			// trees.add(tree);
			Tree subTree = null;
			for (BusinessAppredit appredit : findStandardBusinessAppredit) {
				//subTree = new Tree(appredit.getAppid(), tree.getId(),appredit.getAppname(), "", null);
				subTree = new Tree(appredit.getAppid(), Constant.TREE_ROOT_SIGN,appredit.getAppname(), "", null);
				trees.add(subTree);
			}
		}
	}

}
