@javax.xml.bind.annotation.XmlSchema(namespace = "http://NewCapCert.com/CapCertAuthWebService/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cn.newcapec.function.platform.u;
