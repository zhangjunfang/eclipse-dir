服务提供测试访问地址【2中方案】
方案一：http://192.168.101.108:8080/restful/collectService/collect/getIndustryList  获取行业列表服务
方案二：http://192.168.101.108:8080/controller/collectService/collect/addIndustryUI 获取行业列表服务

这个只是个例子 ，不保证生产环境的稳定性。希望大家提出建议

交流方式 QQ： 419692181

欢迎大家拍砖