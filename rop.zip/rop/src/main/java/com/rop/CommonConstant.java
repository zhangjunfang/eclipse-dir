/**
 * Copyright：中软海晟信息科技有限公司 版权所有 违者必究 2013 
 */
package com.rop;

/**
 * @author : chenxh(quickselect@163.com)
 * @date: 13-11-1
 */
public class CommonConstant {

    public static final String ERROR_TOKEN = "@@$-ERROR_TOKEN$-@@";
}
